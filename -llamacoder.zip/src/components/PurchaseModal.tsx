import { useState } from 'react';
import { Button } from '../components/ui/button';
import { CheckCircle2, Download, ExternalLink } from 'lucide-react';

interface PurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  bookTitle: string;
  bookPrice: number;
  downloadUrl: string;
}

export function PurchaseModal({ isOpen, onClose, bookTitle, bookPrice, downloadUrl }: PurchaseModalProps) {
  const [showSuccess, setShowSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownload = () => {
    window.open(downloadUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl">
        {showSuccess ? (
          <div className="text-center">
            <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8 text-emerald-500" />
            </div>
            <h3 className="text-2xl font-bold text-slate-100 mb-2">Purchase Successful!</h3>
            <p className="text-slate-400 mb-6">
              Thank you for purchasing <span className="text-amber-400 font-semibold">{bookTitle}</span>. 
              Your download is ready.
            </p>
            <div className="space-y-3">
              <Button 
                onClick={handleDownload}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Your E-Book
              </Button>
              <Button 
                onClick={onClose}
                variant="outline"
                className="w-full border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Close
              </Button>
            </div>
          </div>
        ) : (
          <div>
            <h3 className="text-xl font-bold text-slate-100 mb-4">Complete Your Purchase</h3>
            <div className="bg-slate-900/50 rounded-lg p-4 mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-slate-300">{bookTitle}</span>
                <span className="text-amber-400 font-bold">${bookPrice}</span>
              </div>
              <div className="text-xs text-slate-500">Secure payment via Stripe</div>
            </div>
            <div className="flex gap-3">
              <Button 
                onClick={() => setShowSuccess(true)}
                className="flex-1 bg-amber-500 hover:bg-amber-600 text-slate-900 font-semibold"
              >
                Confirm Purchase
              </Button>
              <Button 
                onClick={onClose}
                variant="outline"
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}