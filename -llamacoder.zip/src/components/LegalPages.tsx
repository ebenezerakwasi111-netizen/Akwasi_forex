import { useState } from 'react';
import { Button } from '../components/ui/button';
import { X, FileText, Shield, RefreshCw } from 'lucide-react';

type LegalPage = 'terms' | 'privacy' | 'refund' | null;

export function LegalPages() {
  const [openPage, setOpenPage] = useState<LegalPage>(null);

  const pages = {
    terms: {
      title: 'Terms of Service',
      icon: FileText,
      content: `
        <h2 class="text-xl font-bold text-slate-100 mb-4">1. Acceptance of Terms</h2>
        <p class="text-slate-300 mb-4">By accessing and using TradeLearn, you accept and agree to be bound by the terms and provision of this agreement.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">2. Use License</h2>
        <p class="text-slate-300 mb-4">Permission is granted to temporarily download one copy of the materials on TradeLearn for personal, non-commercial transitory viewing only.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">3. Disclaimer</h2>
        <p class="text-slate-300 mb-4">The materials on TradeLearn are provided 'as is'. TradeLearn makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">4. Trading Risk Warning</h2>
        <p class="text-slate-300 mb-4">Trading forex and CFDs carries a high level of risk and may not be suitable for all investors. The educational materials provided are for informational purposes only and do not constitute financial advice.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">5. Limitations</h2>
        <p class="text-slate-300 mb-4">In no event shall TradeLearn or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on TradeLearn.</p>
      `
    },
    privacy: {
      title: 'Privacy Policy',
      icon: Shield,
      content: `
        <h2 class="text-xl font-bold text-slate-100 mb-4">1. Information We Collect</h2>
        <p class="text-slate-300 mb-4">We collect information you provide directly to us, such as when you create an account, make a purchase, or contact us for support.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">2. How We Use Your Information</h2>
        <p class="text-slate-300 mb-4">We use the information we collect to process transactions, send you technical notices and support messages, and respond to your comments and questions.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">3. Information Sharing</h2>
        <p class="text-slate-300 mb-4">We do not sell, trade, or otherwise transfer your personal information to third parties without your consent, except as described in this policy.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">4. Payment Processing</h2>
        <p class="text-slate-300 mb-4">We use Stripe to process payments. Your payment information is encrypted and secure. We do not store your credit card details.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">5. Data Security</h2>
        <p class="text-slate-300 mb-4">We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.</p>
      `
    },
    refund: {
      title: 'Refund Policy',
      icon: RefreshCw,
      content: `
        <h2 class="text-xl font-bold text-slate-100 mb-4">1. Digital Products</h2>
        <p class="text-slate-300 mb-4">Due to the nature of digital products, all sales are final. Once you have downloaded the e-book, we cannot offer a refund.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">2. Exception Cases</h2>
        <p class="text-slate-300 mb-4">Refunds may be considered in the following cases:</p>
        <ul class="list-disc list-inside text-slate-300 mb-4 space-y-2">
          <li>The product file is technically defective and cannot be replaced</li>
          <li>You were accidentally charged twice for the same product</li>
          <li>The product description was significantly misleading</li>
        </ul>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">3. How to Request a Refund</h2>
        <p class="text-slate-300 mb-4">To request a refund, contact us at support@tradelearn.com within 7 days of purchase. Include your order number and a detailed explanation of the issue.</p>
        
        <h2 class="text-xl font-bold text-slate-100 mb-4">4. Processing Time</h2>
        <p class="text-slate-300 mb-4">Refund requests are typically processed within 5-10 business days. The refund will be credited to your original payment method.</p>
      `
    }
  };

  if (!openPage) return null;

  const page = pages[openPage];
  const Icon = page.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-slate-800 border border-slate-700 rounded-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden shadow-2xl flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <Icon className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-slate-100">{page.title}</h2>
          </div>
          <Button
            onClick={() => setOpenPage(null)}
            variant="ghost"
            size="icon"
            className="text-slate-400 hover:text-slate-100"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6">
          <div 
            className="prose prose-invert prose-slate max-w-none"
            dangerouslySetInnerHTML={{ __html: page.content }}
          />
        </div>
        
        <div className="p-6 border-t border-slate-700">
          <Button
            onClick={() => setOpenPage(null)}
            className="w-full bg-slate-700 hover:bg-slate-600 text-white"
          >
            I Understand
          </Button>
        </div>
      </div>
    </div>
  );
}