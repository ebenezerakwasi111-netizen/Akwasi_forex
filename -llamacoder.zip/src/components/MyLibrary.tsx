import { useState } from 'react';
import { Book } from '../types';
import { Button } from './ui/button';
import { ChevronDown, ChevronUp, Download, BookOpen } from 'lucide-react';

interface MyLibraryProps {
  isOpen: boolean;
  books: Book[];
  onDownload: (book: Book) => void;
  onClose: () => void;
}

export function MyLibrary({ isOpen, books, onDownload, onClose }: MyLibraryProps) {
  // Handle undefined books array
  const ownedBooks = books || [];

  if (ownedBooks.length === 0) return null;

  return (
    <div className={`mb-8 bg-slate-800/50 border border-slate-700 rounded-xl overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-100">My Library</h3>
              <p className="text-sm text-slate-400">{ownedBooks.length} book{ownedBooks.length !== 1 ? 's' : ''} owned</p>
            </div>
          </div>
          <Button
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-slate-400 hover:text-slate-100"
          >
            <ChevronUp className="w-5 h-5" />
          </Button>
        </div>

        <div className="grid gap-3">
          {ownedBooks.map((book) => (
            <div
              key={book.id}
              className="flex items-center justify-between p-4 bg-slate-900/50 rounded-lg border border-slate-700 hover:border-slate-600 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-14 bg-gradient-to-br from-slate-700 to-slate-800 rounded flex items-center justify-center flex-shrink-0">
                  <span className="text-amber-400 text-lg font-bold">PDF</span>
                </div>
                <div>
                  <h4 className="text-slate-100 font-medium">{book.title}</h4>
                  <p className="text-slate-400 text-sm">{book.subtitle}</p>
                </div>
              </div>
              <Button
                onClick={() => onDownload(book)}
                size="sm"
                className="bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}