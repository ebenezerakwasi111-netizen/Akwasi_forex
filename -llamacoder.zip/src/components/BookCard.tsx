import { Book } from '../types';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Check, Download, Lock, ShoppingCart } from 'lucide-react';
import { useState } from 'react';
import { createCheckoutSession } from '../utils/stripe';

interface BookCardProps {
  book: Book;
  isPurchased: boolean;
  userId: string | null;
  onPurchase: (bookId: string) => void;
  onDownload: (bookId: string) => void;
}

export function BookCard({ book, isPurchased, userId, onPurchase, onDownload }: BookCardProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleBuyClick = async () => {
    if (!userId) {
      // Redirect to login/signup
      window.location.href = '/auth?redirect=' + encodeURIComponent(window.location.pathname);
      return;
    }

    setIsLoading(true);
    try {
      const checkoutUrl = await createCheckoutSession(book.id, book.stripePriceId);
      // Redirect to Stripe Checkout
      window.location.href = checkoutUrl;
    } catch (error) {
      console.error('Purchase failed:', error);
      alert('Failed to initiate checkout. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadClick = () => {
    onDownload(book.id);
  };

  return (
    <Card className="bg-slate-800 border-slate-700 hover:border-amber-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/10">
      <CardHeader className="p-0">
        <div className="relative aspect-[3/4] overflow-hidden rounded-t-xl bg-slate-900">
          <img
            src={book.coverImage}
            alt={book.title}
            className="w-full h-full object-cover"
          />
          {isPurchased && (
            <Badge className="absolute top-3 right-3 bg-emerald-500 hover:bg-emerald-600">
              <Check className="w-3 h-3 mr-1" />
              Owned
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        <CardTitle className="text-xl text-slate-100 mb-1">{book.title}</CardTitle>
        <CardDescription className="text-slate-400 mb-3">{book.subtitle}</CardDescription>
        
        <p className="text-sm text-slate-300 mb-4 line-clamp-2">{book.description}</p>
        
        <div className="space-y-2 mb-4">
          {book.features.slice(0, 3).map((feature, index) => (
            <div key={index} className="flex items-center text-xs text-slate-400">
              <Check className="w-3 h-3 mr-2 text-amber-400" />
              {feature}
            </div>
          ))}
        </div>
        
        <div className="flex items-baseline gap-1">
          <span className="text-3xl font-bold text-amber-400">${book.price}</span>
          <span className="text-slate-500 text-sm">USD</span>
        </div>
      </CardContent>
      
      <CardFooter className="p-6 pt-0">
        {isPurchased ? (
          <Button 
            onClick={handleDownloadClick}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
          >
            <Download className="w-4 h-4 mr-2" />
            Download Now
          </Button>
        ) : (
          <Button 
            onClick={handleBuyClick}
            disabled={isLoading}
            className="w-full bg-amber-500 hover:bg-amber-600 text-slate-900 font-semibold"
          >
            {isLoading ? (
              <>Processing...</>
            ) : (
              <>
                <ShoppingCart className="w-4 h-4 mr-2" />
                Buy Now
              </>
            )}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}