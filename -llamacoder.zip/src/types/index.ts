export interface Book {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  price: number;
  coverImage: string;
  pdfUrl: string;
  stripePriceId: string; // Real Stripe Price ID
  features: string[];
}

export interface Purchase {
  id: string;
  bookId: string;
  userId: string;
  stripeSessionId: string;
  purchasedAt: string;
  downloadCount: number;
}

export interface User {
  id: string;
  email: string;
  name?: string;
}