const STORAGE_KEY = 'akwasi_forex_purchases';

export const storage = {
  /**
   * Get all purchased book IDs from localStorage
   */
  getPurchasedBooks(): string[] {
    if (typeof window === 'undefined') return [];
    
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return [];
    }
  },

  /**
   * Save purchased book IDs to localStorage
   */
  savePurchasedBooks(bookIds: string[]): void {
    if (typeof window === 'undefined') return;
    
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(bookIds));
    } catch (error) {
      console.error('Error writing to localStorage:', error);
    }
  },

  /**
   * Check if a specific book has been purchased
   */
  hasPurchased(bookId: string): boolean {
    const purchasedBooks = this.getPurchasedBooks();
    return purchasedBooks.includes(bookId);
  },

  /**
   * Add a book to purchased list
   */
  addPurchase(bookId: string): void {
    const purchasedBooks = this.getPurchasedBooks();
    if (!purchasedBooks.includes(bookId)) {
      this.savePurchasedBooks([...purchasedBooks, bookId]);
    }
  },

  /**
   * Clear all purchases (useful for testing)
   */
  clearPurchases(): void {
    if (typeof window === 'undefined') return;
    
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (error) {
      console.error('Error clearing localStorage:', error);
    }
  }
};