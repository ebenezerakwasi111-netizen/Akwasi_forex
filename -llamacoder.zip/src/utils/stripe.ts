/**
 * Initialize Stripe Checkout Session
 * This calls your backend API to create a Stripe checkout session
 */
export async function createCheckoutSession(bookId: string, priceId: string): Promise<string> {
  try {
    const response = await fetch('/api/checkout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ bookId, priceId }),
    });

    if (!response.ok) {
      throw new Error('Failed to create checkout session');
    }

    const { url } = await response.json();
    return url;
  } catch (error) {
    console.error('Checkout error:', error);
    throw error;
  }
}

/**
 * Verify if user has purchased a book
 * Calls backend to check database
 */
export async function verifyPurchase(bookId: string, userId: string): Promise<boolean> {
  try {
    const response = await fetch(`/api/verify-purchase?bookId=${bookId}&userId=${userId}`);
    
    if (!response.ok) {
      throw new Error('Failed to verify purchase');
    }

    const { purchased } = await response.json();
    return purchased;
  } catch (error) {
    console.error('Verification error:', error);
    return false;
  }
}

/**
 * Get secure download URL for purchased book
 */
export async function getDownloadUrl(bookId: string, userId: string): Promise<string> {
  try {
    const response = await fetch(`/api/download?bookId=${bookId}&userId=${userId}`);
    
    if (!response.ok) {
      throw new Error('Failed to get download URL');
    }

    const { url } = await response.json();
    return url;
  } catch (error) {
    console.error('Download error:', error);
    throw error;
  }
}