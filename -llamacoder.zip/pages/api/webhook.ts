import { NextApiRequest, NextApiResponse } from 'next';
import Stripe from 'stripe';
import { supabase } from '../../lib/supabase';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-06-20',
});

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const buf = await buffer(req);
  const sig = req.headers['stripe-signature']!;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      buf,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err);
    return res.status(400).send('Webhook signature verification failed');
  }

  // Handle the event
  switch (event.type) {
    case 'checkout.session.completed':
      const session = event.data.object as Stripe.Checkout.Session;
      const bookId = session.metadata?.bookId;
      const customerEmail = session.customer_details?.email;

      if (bookId && customerEmail) {
        // Create or get user
        const { data: user } = await supabase
          .from('users')
          .select('id')
          .eq('email', customerEmail)
          .single();

        let userId = user?.id;

        if (!userId) {
          const { data: newUser } = await supabase
            .from('users')
            .insert({ email: customerEmail })
            .select('id')
          .single();
          userId = newUser?.id;
        }

        // Record purchase
        if (userId) {
          await supabase.from('purchases').insert({
            book_id: bookId,
            user_id: userId,
            stripe_session_id: session.id,
            purchased_at: new Date().toISOString(),
          });
        }
      }
      break;

    default:
      console.log(`Unhandled event type ${event.type}`);
  }

  res.json({ received: true });
}